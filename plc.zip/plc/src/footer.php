<footer>
    <p style="font-size: 1.5em;">Copyright PLC co.,ltd. &nbsp;&nbsp;&nbsp; All Rights Reserved</p>
</footer>
