<footer>
    <p>Copyright PLC co.,ltd. &nbsp;&nbsp;&nbsp; All Rights Reserved</p>
</footer>
