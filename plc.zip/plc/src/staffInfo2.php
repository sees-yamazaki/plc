<?php
session_start();

// ログイン状態チェック
if (!isset($_SESSION["NAME"])) {
    header("Location: Logout.php");
    exit;
}

$uSeq = $_SESSION['SEQ'];

$ini = parse_ini_file('../common.ini', FALSE);

if (!empty($_SESSION["LEVEL"])) {

    try {

        require_once 'dns.php';
        
        
        if(isset($_POST['staffPw'])){

            $password = $_POST['password'];
            $pass = $_POST['pass'];
            
            
            if($password==$pass){
                $sql = "UPDATE `employee` SET `employee_pw`=? WHERE `employee_seq`=?";
                $stmt = $pdo->prepare($sql);
                $stmt->execute(array(
                    $password,
                    $uSeq));

                    $_SESSION['MSG'] = "パスワードを更新しました。";

                header("Location: ./staff.php");

            }else{
                $errorMessage = 'パスワードが一致しません。';
            }
            


        }


    } catch (PDOException $e) {
        $errorMessage = 'データベースエラー';
        if(strcmp("1",$ini['debug'])==0){
            echo $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html>

<head class="wf-sawarabigothic">
    <meta charset="utf-8">
    <link rel="stylesheet" href="../css/staff.css">
    <link rel="stylesheet" type="text/css" href="../css/hiraku.css">
    <script src="http://code.jquery.com/jquery-2.2.4.min.js"></script>
    <script src="../js/hiraku.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Sawarabi+Gothic" rel="stylesheet">
</head>

<body>

    <?php include('./staffMenu.php'); ?>

    <form action="staffPw.php" method="POST" onsubmit="return pwcheck()">
    <table class="work fnt2em">
        <tbody>
            <tr><td class="err" colspan=2><?php echo $errorMessage; ?></td></tr>
            <tr>
                <th class="arrow_box">ジュウショ</th>
                <td><textarea name="address_kana"  class="fnt1p5em" rows=3><?php echo $address_kana; ?></textarea></td>
            </tr>
            <tr>
                <th class="arrow_box">住所</th>
                <td><textarea name="address"  class="fnt1p5em" rows=3><?php echo $address; ?></textarea></td>
            </tr>
            <tr>
                <th><span class="required">連絡先<span class="fnt1em"> (13)</span></span></th>
                <td><input type="tel" id="tel1" name="tel1" class="fnt1p5em" maxlength=13  style="ime-mode:disabled" placeholder="090-1234-5678" pattern="\d{2,4}-?\d{3,4}-?\d{3,4}" title="電話番号" required value="<?php echo $tel1; ?>"></td>
            </tr>
            <tr>
                <th>携帯電話<span class="fnt1em"> (13)</span></th>
                <td><input type="tel" id="tel2" name="tel2" class="fnt1p5em" maxlength=13  style="ime-mode:disabled" placeholder="090-1234-5678" pattern="\d{2,4}-?\d{3,4}-?\d{3,4}" title="電話番号" value="<?php echo $tel2; ?>"></td>
            </tr>
            <tr>
                <th>留守電の有無</th>
                <td>
                    <?php if($answering=="1"){ ?>
                    <input type="radio" name="answering" value="1" checked>有
                    <input type="radio" name="answering" value="2">無
                    <?php }else{ ?>
                    <input type="radio" name="answering" value="1">有
                    <input type="radio" name="answering" value="2" checked>無
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <th>FAXの有無</th>
                <td>
                    <?php if($fax=="1"){ ?>
                    <input type="radio" name="fax" value="1" checked>有
                    <input type="radio" name="fax" value="2">無
                    <?php }else{ ?>
                    <input type="radio" name="fax" value="1">有
                    <input type="radio" name="fax" value="2" checked>無
                    <?php } ?>
                </td>
            </tr>
            <tr>
                <th><span class="required">E-mail：携帯<span class="f50P"> (50)</span></span></th>
                <td><input type="email" id="email1" name="email1" style="ime-mode:disabled" class="fnt1p5em" maxlength=50 placeholder="localname@domain.com" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="メールアドレス" required value="<?php echo $email1; ?>"></td>
            </tr>
            <tr>
                <th>E-mail：PC<span class="fnt1em"> (50)</span></th>
                <td><input type="email" id="email2" name="email2" style="ime-mode:disabled" class="fnt1p5em" maxlength=50 placeholder="localname@domain.com" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" title="メールアドレス" value="<?php echo $email2; ?>"></td>
            </tr>
            <tr>
                <th><span class="required">指定アドレス</span></th>
                <td>
                    <?php if(!isset($sex)){ ?>
                    <input type="radio" id="priority_email1" name="priority_email" value="1" required>携帯
                    <input type="radio" name="priority_email" value="2">PC
                    <?php }elseif($sex=="1"){ ?>
                    <input type="radio" id="priority_email1" name="priority_email" value="1" required checked>携帯
                    <input type="radio" name="priority_email" value="2">PC
                    <?php }else{ ?>
                    <input type="radio" id="priority_email1" name="priority_email" value="1" required>携帯
                    <input type="radio" name="priority_email" value="2" checked>PC
                    <?php } ?>
                </td>
            </tr>

            <tr><td colspan="2"><button type=submit name="staffPw" class="btn-sticky">登録</button></td></tr>
        </tbody>
    </table>
    </form>


</body>

</html>
